package controller;

import model.Book;
import model.BookDAO;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.MultipartConfig;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.Part;

import java.io.File;
import java.io.IOException;
import java.nio.file.Paths;

@WebServlet("/AddBookServlet")
@MultipartConfig(
    fileSizeThreshold = 1024 * 1024 * 2,  // 2MB
    maxFileSize = 1024 * 1024 * 10,       // 10MB
    maxRequestSize = 1024 * 1024 * 50     // 50MB
)

public class AddBookServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;
    private static final String SAVE_DIR = "images";
    
    protected void doGet(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        try {
            BookDAO dao = new BookDAO();
            List<Book> books = dao.getAllBooks();
            if (books == null) {
                request.setAttribute("errorMessage", "Book list is null. Possible database issue.");
            } else {
                request.setAttribute("books", books);
            }
            dao.close();
        } catch (Exception e) {
            e.printStackTrace();
            request.setAttribute("errorMessage", "Error fetching books: " + e.getMessage());
        }

        // Forward to the JSP page
        request.getRequestDispatcher("product-details.jsp").forward(request, response);
    }


    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        // Get form parameters
        String name = request.getParameter("name");
        String description = request.getParameter("description");
        String category = request.getParameter("category");

        // Validate inputs
        if (name == null || name.trim().isEmpty() ||
            description == null || description.trim().isEmpty() ||
            category == null || category.trim().isEmpty()) {
            request.setAttribute("errorMessage", "❌ All fields are required.");
            request.getRequestDispatcher("add-book.jsp").forward(request, response);
            return;
        }

        // Handle image upload
        Part imagePart = request.getPart("image");
        String fileName = Paths.get(imagePart.getSubmittedFileName()).getFileName().toString();

        // Sanitize file name
        fileName = fileName.replaceAll("[^a-zA-Z0-9\\.\\-]", "_");

        String appPath = request.getServletContext().getRealPath("");
        String savePath = appPath + File.separator + SAVE_DIR;

        File fileSaveDir = new File(savePath);
        if (!fileSaveDir.exists()) {
            fileSaveDir.mkdirs();
        }

        // Save the file
        imagePart.write(savePath + File.separator + fileName);
        String imagePath = SAVE_DIR + File.separator + fileName;

        // Create Book object
        Book book = new Book();
        book.setName(name);
        book.setDescription(description);
        book.setCategory(category);
        book.setImagePath(imagePath);

        // Insert into database using DAO
        BookDAO bookDAO = new BookDAO();
        boolean isAdded = bookDAO.addBook(book);

        if (isAdded) {
            request.setAttribute("successMessage", "✅ Book added successfully!");
        } else {
            request.setAttribute("errorMessage", "❌ Failed to add the book.");
        }

        // Forward to JSP
        request.getRequestDispatcher("add-book.jsp").forward(request, response);
    }
}

package controller;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import java.io.IOException;
import java.sql.*;

@WebServlet("/CheckLoginEducation")
public class CheckLoginEducation extends HttpServlet {
    private static final long serialVersionUID = 1L;

    // JDBC connection details
    private static final String DB_URL = "jdbc:mysql://localhost:3306/library_system?useSSL=false&serverTimezone=UTC";
    private static final String DB_USER = "root";
    private static final String DB_PASS = "SAranG193@"; // Change this in production!

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        String uname = request.getParameter("uname");
        String pwd = request.getParameter("pwd");

        boolean isValid = false;

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASS)) {
                String sql = "SELECT * FROM admin_users WHERE username = ? AND password = ?";
                PreparedStatement ps = conn.prepareStatement(sql);
                ps.setString(1, uname);
                ps.setString(2, pwd); // For production, use hashed password checking
                ResultSet rs = ps.executeQuery();

                if (rs.next()) {
                    isValid = true;
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        if (isValid) {
            HttpSession session = request.getSession();
            session.setAttribute("adminUser", uname);
            response.sendRedirect("adminHome.jsp");
        } else {
            request.setAttribute("msg", "Invalid Username or Password!");
            request.getRequestDispatcher("Admin.jsp").forward(request, response);
        }
    }
}
